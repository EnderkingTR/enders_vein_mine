package enderveinmine.mixin;

import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_4970;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_4970.class)
public interface BlockBehaviourAccessor {
    @Invoker("spawnAfterBreak")
    void invokeSpawnAfterBreak(class_2680 state, class_3218 level, class_2338 pos, class_1799 tool, boolean dropExperience);
}
