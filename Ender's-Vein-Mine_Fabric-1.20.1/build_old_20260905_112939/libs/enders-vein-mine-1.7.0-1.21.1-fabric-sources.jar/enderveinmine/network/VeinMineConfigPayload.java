package enderveinmine.network;

import enderveinmine.VeinMine;
import enderveinmine.config.VeinMineConfig;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public record VeinMineConfigPayload(int maxBlocks, boolean damageTool, String activationMode, String shapeMode, String customShape, boolean renderOutline, boolean directDropToInventory, boolean preventToolBreak, boolean hungerDrain) implements class_8710 {
    public static final class_8710.class_9154<VeinMineConfigPayload> ID = new class_8710.class_9154<>(VeinMine.id("config"));
    public static final class_9139<class_9129, VeinMineConfigPayload> CODEC = class_9139.method_56437(
            (buf, payload) -> payload.write(buf),
            VeinMineConfigPayload::new
    );

    public VeinMineConfigPayload(class_9129 buf) {
        this(buf.readInt(), buf.readBoolean(), buf.method_19772(), buf.method_19772(), buf.method_19772(), buf.readBoolean(), buf.readBoolean(), buf.readBoolean(), buf.readBoolean());
    }

    public void write(class_9129 buf) {
        buf.method_53002(maxBlocks);
        buf.method_52964(damageTool);
        buf.method_10814(activationMode);
        buf.method_10814(shapeMode);
        buf.method_10814(customShape);
        buf.method_52964(renderOutline);
        buf.method_52964(directDropToInventory);
        buf.method_52964(preventToolBreak);
        buf.method_52964(hungerDrain);
    }

    public VeinMineConfigPayload(VeinMineConfig config) {
        this(config.maxBlocks, config.damageTool, config.activationMode.name(), config.shapeMode.name(), config.customShape, config.renderOutline, config.directDropToInventory, config.preventToolBreak, config.hungerDrain);
    }

    @Override
    public class_8710.class_9154<? extends class_8710> method_56479() {
        return ID;
    }
}
