package enderveinmine.network;

import enderveinmine.VeinMine;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record VeinMineActivePayload(boolean active) implements class_8710 {
    public static final class_8710.class_9154<VeinMineActivePayload> ID = new class_8710.class_9154<>(VeinMine.id("active"));
    public static final class_9139<class_9129, VeinMineActivePayload> CODEC = class_9139.method_56434(
            class_9135.field_48547, VeinMineActivePayload::active,
            VeinMineActivePayload::new
    );

    @Override
    public class_8710.class_9154<? extends class_8710> method_56479() {
        return ID;
    }
}
