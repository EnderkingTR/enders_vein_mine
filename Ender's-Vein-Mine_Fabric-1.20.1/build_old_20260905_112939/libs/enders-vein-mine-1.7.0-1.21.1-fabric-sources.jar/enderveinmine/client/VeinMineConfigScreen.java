package enderveinmine.client;

import enderveinmine.config.VeinMineConfig;
import me.shedaniel.clothconfig2.api.ConfigBuilder;
import me.shedaniel.clothconfig2.api.ConfigCategory;
import me.shedaniel.clothconfig2.api.ConfigEntryBuilder;
import net.minecraft.class_2561;
import net.minecraft.class_437;

public class VeinMineConfigScreen {
    
    public static class_437 create(class_437 parent) {
        ConfigBuilder builder = ConfigBuilder.create()
                .setParentScreen(parent)
                .setTitle(class_2561.method_43471("config.veinmine.title"));
        
        builder.setSavingRunnable(() -> {
            VeinMineConfig.save();
            VeinMineClient.sendConfigToServer();
        });
        
        ConfigCategory general = builder.getOrCreateCategory(class_2561.method_43471("config.veinmine.category.general"));
        ConfigEntryBuilder entryBuilder = builder.entryBuilder();
        
        VeinMineConfig config = VeinMineConfig.INSTANCE;
        
        general.addEntry(entryBuilder.startIntField(class_2561.method_43471("config.veinmine.maxBlocks"), config.maxBlocks)
                .setDefaultValue(64)
                .setTooltip(class_2561.method_43471("config.veinmine.maxBlocks.tooltip"))
                .setSaveConsumer(newValue -> config.maxBlocks = newValue)
                .build());
                
        general.addEntry(entryBuilder.startBooleanToggle(class_2561.method_43471("config.veinmine.damageTool"), config.damageTool)
                .setDefaultValue(true)
                .setTooltip(class_2561.method_43471("config.veinmine.damageTool.tooltip"))
                .setSaveConsumer(newValue -> config.damageTool = newValue)
                .build());
                
        general.addEntry(entryBuilder.startEnumSelector(class_2561.method_43471("config.veinmine.activationMode"), VeinMineConfig.ActivationMode.class, config.activationMode)
                .setDefaultValue(VeinMineConfig.ActivationMode.HOLD_KEY)
                .setTooltip(class_2561.method_43471("config.veinmine.activationMode.tooltip"))
                .setEnumNameProvider(mode -> class_2561.method_43471("config.veinmine.enum.activation." + ((VeinMineConfig.ActivationMode) mode).name().toLowerCase(java.util.Locale.ROOT)))
                .setSaveConsumer(newValue -> config.activationMode = newValue)
                .build());
                
        general.addEntry(entryBuilder.startEnumSelector(class_2561.method_43471("config.veinmine.shapeMode"), VeinMineConfig.ShapeMode.class, config.shapeMode)
                .setDefaultValue(VeinMineConfig.ShapeMode.SHAPELESS)
                .setTooltip(class_2561.method_43471("config.veinmine.shapeMode.tooltip"))
                .setEnumNameProvider(mode -> class_2561.method_43471("config.veinmine.enum.shape." + ((VeinMineConfig.ShapeMode) mode).name().toLowerCase(java.util.Locale.ROOT)))
                .setSaveConsumer(newValue -> config.shapeMode = newValue)
                .build());
                
        general.addEntry(entryBuilder.startStrField(class_2561.method_43471("config.veinmine.customShape"), config.customShape)
                .setDefaultValue("3x3x3")
                .setTooltip(class_2561.method_43471("config.veinmine.customShape.tooltip"))
                .setSaveConsumer(newValue -> config.customShape = newValue)
                .build());
                
        general.addEntry(entryBuilder.startBooleanToggle(class_2561.method_43471("config.veinmine.renderOutline"), config.renderOutline)
                .setDefaultValue(true)
                .setTooltip(class_2561.method_43471("config.veinmine.renderOutline.tooltip"))
                .setSaveConsumer(newValue -> config.renderOutline = newValue)
                .build());
                
        general.addEntry(entryBuilder.startBooleanToggle(class_2561.method_43471("config.veinmine.directDrop"), config.directDropToInventory)
                .setDefaultValue(false)
                .setTooltip(class_2561.method_43471("config.veinmine.directDrop.tooltip"))
                .setSaveConsumer(newValue -> config.directDropToInventory = newValue)
                .build());
                
        general.addEntry(entryBuilder.startBooleanToggle(class_2561.method_43471("config.veinmine.preventToolBreak"), config.preventToolBreak)
                .setDefaultValue(true)
                .setTooltip(class_2561.method_43471("config.veinmine.preventToolBreak.tooltip"))
                .setSaveConsumer(newValue -> config.preventToolBreak = newValue)
                .build());
                
        general.addEntry(entryBuilder.startBooleanToggle(class_2561.method_43471("config.veinmine.hungerDrain"), config.hungerDrain)
                .setDefaultValue(true)
                .setTooltip(class_2561.method_43471("config.veinmine.hungerDrain.tooltip"))
                .setSaveConsumer(newValue -> config.hungerDrain = newValue)
                .build());
                
        return builder.build();
    }
}
