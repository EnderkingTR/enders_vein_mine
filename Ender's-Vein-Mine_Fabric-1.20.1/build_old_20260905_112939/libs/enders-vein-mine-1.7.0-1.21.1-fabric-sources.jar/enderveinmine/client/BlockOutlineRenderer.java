package enderveinmine.client;

import enderveinmine.config.VeinMineConfig;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_239;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import net.minecraft.class_4587;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Set;

public class BlockOutlineRenderer implements WorldRenderEvents.Last {

    private final Set<class_2338> cachedBlocks = new HashSet<>();
    private net.minecraft.class_265 cachedShape = net.minecraft.class_259.method_1073();
    private class_2338 cachedOrigin = null;
    private class_2338 lastTargetPos = null;
    private boolean lastActiveState = false;
    private long lastCacheTime = 0;

    public void onLast(WorldRenderContext context) {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || client.field_1687 == null) return;

        boolean isActive = VeinMineClient.isActive();
        boolean configEnabled = VeinMineConfig.INSTANCE.renderOutline;

        if (!isActive || !configEnabled) {
            lastActiveState = isActive;
            return;
        }

        class_239 hitResult = client.field_1765;
        if (hitResult == null || hitResult.method_17783() != class_239.class_240.field_1332) {
            lastTargetPos = null;
            lastActiveState = isActive;
            return;
        }

        class_2338 targetPos = ((class_3965) hitResult).method_17777();
        class_1937 level = client.field_1687;
        class_1657 player = client.field_1724;
        long currentTime = System.currentTimeMillis();

        if (lastTargetPos == null || !lastTargetPos.equals(targetPos) || !lastActiveState || (currentTime - lastCacheTime > 500)) {
            recalculateCache(level, player, targetPos);
            lastTargetPos = targetPos;
            lastActiveState = isActive;
            lastCacheTime = currentTime;
        }

        if (cachedBlocks.isEmpty()) return;

        class_4587 poseStack = context.matrixStack();
        double camX = context.camera().method_19326().field_1352;
        double camY = context.camera().method_19326().field_1351;
        double camZ = context.camera().method_19326().field_1350;

        poseStack.method_22903();
        
        VeinMineConfig config = VeinMineConfig.INSTANCE;
        float[] colors = hexToRgb("FFFFFF");
        float red = colors[0];
        float green = colors[1];
        float blue = colors[2];
        float alpha = 0.4f;
        float fillAlpha = 0.2f;

        // Draw lines first
        net.minecraft.class_4588 consumer = context.consumers().getBuffer(net.minecraft.class_1921.method_23594());
        for (class_2338 pos : cachedBlocks) {
            class_2680 state = level.method_8320(pos);
            if (state.method_26215()) continue;

            class_265 shape = state.method_26218(level, pos);
            if (shape.method_1110()) continue;

            class_4587.class_4665 pose = poseStack.method_23760();
            shape.method_1089((minX, minY, minZ, maxX, maxY, maxZ) -> {
                double x = pos.method_10263() - camX;
                double y = pos.method_10264() - camY;
                double z = pos.method_10260() - camZ;
                
                float fMinX = (float) (x + minX - 0.005);
                float fMinY = (float) (y + minY - 0.005);
                float fMinZ = (float) (z + minZ - 0.005);
                float fMaxX = (float) (x + maxX + 0.005);
                float fMaxY = (float) (y + maxY + 0.005);
                float fMaxZ = (float) (z + maxZ + 0.005);
                
                // Draw lines of the box
                consumer.method_56824(pose, fMinX, fMinY, fMinZ).method_22915(red, green, blue, alpha).method_22914(1, 0, 0);
                consumer.method_56824(pose, fMaxX, fMinY, fMinZ).method_22915(red, green, blue, alpha).method_22914(1, 0, 0);
                consumer.method_56824(pose, fMinX, fMinY, fMinZ).method_22915(red, green, blue, alpha).method_22914(0, 1, 0);
                consumer.method_56824(pose, fMinX, fMaxY, fMinZ).method_22915(red, green, blue, alpha).method_22914(0, 1, 0);
                consumer.method_56824(pose, fMinX, fMinY, fMinZ).method_22915(red, green, blue, alpha).method_22914(0, 0, 1);
                consumer.method_56824(pose, fMinX, fMinY, fMaxZ).method_22915(red, green, blue, alpha).method_22914(0, 0, 1);
                
                consumer.method_56824(pose, fMaxX, fMaxY, fMaxZ).method_22915(red, green, blue, alpha).method_22914(-1, 0, 0);
                consumer.method_56824(pose, fMinX, fMaxY, fMaxZ).method_22915(red, green, blue, alpha).method_22914(-1, 0, 0);
                consumer.method_56824(pose, fMaxX, fMaxY, fMaxZ).method_22915(red, green, blue, alpha).method_22914(0, -1, 0);
                consumer.method_56824(pose, fMaxX, fMinY, fMaxZ).method_22915(red, green, blue, alpha).method_22914(0, -1, 0);
                consumer.method_56824(pose, fMaxX, fMaxY, fMaxZ).method_22915(red, green, blue, alpha).method_22914(0, 0, -1);
                consumer.method_56824(pose, fMaxX, fMaxY, fMinZ).method_22915(red, green, blue, alpha).method_22914(0, 0, -1);
                
                consumer.method_56824(pose, fMinX, fMaxY, fMaxZ).method_22915(red, green, blue, alpha).method_22914(0, -1, 0);
                consumer.method_56824(pose, fMinX, fMinY, fMaxZ).method_22915(red, green, blue, alpha).method_22914(0, -1, 0);
                consumer.method_56824(pose, fMinX, fMaxY, fMaxZ).method_22915(red, green, blue, alpha).method_22914(1, 0, 0);
                consumer.method_56824(pose, fMinX, fMaxY, fMinZ).method_22915(red, green, blue, alpha).method_22914(1, 0, 0);
                
                consumer.method_56824(pose, fMaxX, fMinY, fMinZ).method_22915(red, green, blue, alpha).method_22914(0, 1, 0);
                consumer.method_56824(pose, fMaxX, fMaxY, fMinZ).method_22915(red, green, blue, alpha).method_22914(0, 1, 0);
                consumer.method_56824(pose, fMaxX, fMinY, fMinZ).method_22915(red, green, blue, alpha).method_22914(0, 0, 1);
                consumer.method_56824(pose, fMaxX, fMinY, fMaxZ).method_22915(red, green, blue, alpha).method_22914(0, 0, 1);
            });
        }
        
        // Draw filled quads second
        net.minecraft.class_4588 quadConsumer = context.consumers().getBuffer(net.minecraft.class_1921.method_49047());
        for (class_2338 pos : cachedBlocks) {
            class_2680 state = level.method_8320(pos);
            if (state.method_26215()) continue;

            class_265 shape = state.method_26218(level, pos);
            if (shape.method_1110()) continue;

            class_4587.class_4665 pose = poseStack.method_23760();
            shape.method_1089((minX, minY, minZ, maxX, maxY, maxZ) -> {
                double x = pos.method_10263() - camX;
                double y = pos.method_10264() - camY;
                double z = pos.method_10260() - camZ;
                
                float fMinX = (float) (x + minX - 0.005);
                float fMinY = (float) (y + minY - 0.005);
                float fMinZ = (float) (z + minZ - 0.005);
                float fMaxX = (float) (x + maxX + 0.005);
                float fMaxY = (float) (y + maxY + 0.005);
                float fMaxZ = (float) (z + maxZ + 0.005);
                
                net.minecraft.class_761.method_49041(poseStack, quadConsumer, fMinX, fMinY, fMinZ, fMaxX, fMaxY, fMaxZ, red, green, blue, fillAlpha);
            });
        }
        poseStack.method_22909();
    }
    
    private float[] hexToRgb(String hex) {
        hex = hex.replace("#", "");
        if (hex.length() == 6) {
            return new float[] {
                Integer.valueOf(hex.substring(0, 2), 16) / 255f,
                Integer.valueOf(hex.substring(2, 4), 16) / 255f,
                Integer.valueOf(hex.substring(4, 6), 16) / 255f
            };
        }
        return new float[]{1f, 1f, 1f};
    }

    private void recalculateCache(class_1937 level, class_1657 player, class_2338 startPos) {
        cachedBlocks.clear();

        class_2680 startState = level.method_8320(startPos);
        if (startState.method_26215()) return;

        int maxBlocks = VeinMineConfig.INSTANCE.maxBlocks;
        String shapeModeStr = VeinMineConfig.INSTANCE.shapeMode.name();
        String customShape = VeinMineConfig.INSTANCE.customShape;

        if ("SHAPED".equals(shapeModeStr)) {
            calculateShapedMine(level, startPos, startState, customShape, maxBlocks);
        } else if ("SHAPELESS".equals(shapeModeStr)) {
            calculateShapelessMine(level, startPos, startState, maxBlocks);
        } else {
            calculatePresetMine(level, player, startPos, startState, shapeModeStr, maxBlocks);
        }
    }

    private void calculateShapelessMine(class_1937 level, class_2338 startPos, class_2680 startState, int maxBlocks) {
        class_2248 targetBlock = startState.method_26204();
        Queue<class_2338> queue = new LinkedList<>();
        Set<class_2338> visited = new HashSet<>();

        queue.add(startPos);
        visited.add(startPos);
        cachedBlocks.add(startPos);

        while (!queue.isEmpty() && cachedBlocks.size() < maxBlocks) {
            class_2338 current = queue.poll();

            for (int x = -1; x <= 1; x++) {
                for (int y = -1; y <= 1; y++) {
                    for (int z = -1; z <= 1; z++) {
                        if (x == 0 && y == 0 && z == 0) continue;
                        if (cachedBlocks.size() >= maxBlocks) break;
                        
                        class_2338 offset = current.method_10069(x, y, z);
                        if (!visited.add(offset)) continue;

                        class_2680 state = level.method_8320(offset);
                        if (state.method_26204() == targetBlock) {
                            cachedBlocks.add(offset);
                            queue.add(offset);
                        }
                    }
                    if (cachedBlocks.size() >= maxBlocks) break;
                }
                if (cachedBlocks.size() >= maxBlocks) break;
            }
        }
    }

    private void calculateShapedMine(class_1937 level, class_2338 startPos, class_2680 startState, String customShape, int maxBlocks) {
        float maxHardness = startState.method_26214(level, startPos);
        if (maxHardness < 0) return;

        int dx = 3, dy = 3, dz = 3;
        try {
            String[] parts = customShape.toLowerCase().split("x");
            if (parts.length == 3) {
                dx = Integer.parseInt(parts[0].trim());
                dy = Integer.parseInt(parts[1].trim());
                dz = Integer.parseInt(parts[2].trim());
            }
        } catch (Exception ignored) {
        }

        int hx = dx / 2;
        int hy = dy / 2;
        int hz = dz / 2;

        cachedBlocks.add(startPos);

        for (int x = -hx; x <= hx; x++) {
            for (int y = -hy; y <= hy; y++) {
                for (int z = -hz; z <= hz; z++) {
                    if (x == 0 && y == 0 && z == 0) continue;
                    if (cachedBlocks.size() >= maxBlocks) return;

                    class_2338 pos = startPos.method_10069(x, y, z);
                    class_2680 state = level.method_8320(pos);
                    float hardness = state.method_26214(level, pos);

                    if (hardness >= 0 && hardness <= maxHardness && !state.method_26215()) {
                        cachedBlocks.add(pos);
                    }
                }
            }
        }
    }

    private boolean isSameBlockGroup(class_2248 target, class_2248 stateBlock) {
        if (target == stateBlock) return true;
        Set<class_2248> stoneGroup = Set.of(
            net.minecraft.class_2246.field_10340,
            net.minecraft.class_2246.field_10445,
            net.minecraft.class_2246.field_28888,
            net.minecraft.class_2246.field_10115,
            net.minecraft.class_2246.field_10474,
            net.minecraft.class_2246.field_10508,
            net.minecraft.class_2246.field_29031,
            net.minecraft.class_2246.field_27165
        );
        return stoneGroup.contains(target) && stoneGroup.contains(stateBlock);
    }

    private void calculatePresetMine(class_1937 level, class_1657 player, class_2338 startPos, class_2680 startState, String mode, int maxBlocks) {
        class_2248 targetBlock = startState.method_26204();
        net.minecraft.class_2350 viewDir = net.minecraft.class_2350.method_10159(player)[0];

        net.minecraft.class_2350 upDir = net.minecraft.class_2350.field_11036;
        net.minecraft.class_2350 rightDir; 
        if (viewDir == net.minecraft.class_2350.field_11036 || viewDir == net.minecraft.class_2350.field_11033) {
            net.minecraft.class_2350 playerFacing = player.method_5735();
            if (playerFacing.method_10166() == net.minecraft.class_2350.class_2351.field_11052) {
                playerFacing = net.minecraft.class_2350.field_11043;
            }
            upDir = playerFacing.method_10153(); // backward relative to player's horizontal looking
            rightDir = playerFacing.method_10170();
        } else {
            rightDir = viewDir.method_10170();
        }

        for (int depth = 0; depth < maxBlocks; depth++) {
            if (cachedBlocks.size() >= maxBlocks) break;

            int minR = 0, maxR = 0;
            int minU = 0, maxU = 0;
            int fOffset = depth;
            int uOffset = 0;
            
            switch (mode) {
                case "TUNNEL_3X3":
                    minR = -1; maxR = 1;
                    minU = -1; maxU = 1;
                    break;
                case "TUNNEL_2X1":
                    minR = 0; maxR = 0; // width 1
                    minU = 0; maxU = 1; // height 2
                    break;
                case "STAIRS_UP":
                    minR = 0; maxR = 0; // width 1
                    minU = 0; maxU = 2; // 3 blocks high
                    uOffset = depth; // go up 1 per depth
                    break;
                case "STAIRS_DOWN":
                    minR = 0; maxR = 0; // width 1
                    minU = 0; maxU = 2; // 3 blocks high
                    uOffset = -depth; // go down 1 per depth
                    break;
                case "TUNNEL_1X1":
                    minR = 0; maxR = 0;
                    minU = 0; maxU = 0;
                    break;
            }

            for (int r = minR; r <= maxR; r++) {
                for (int u = minU; u <= maxU; u++) {
                    if (cachedBlocks.size() >= maxBlocks) return;

                    class_2338 pos = startPos
                        .method_10079(viewDir, fOffset)
                        .method_10079(rightDir, r)
                        .method_10079(upDir, u + uOffset);
                    
                    class_2680 state = level.method_8320(pos);
                    
                    if (isSameBlockGroup(targetBlock, state.method_26204())) {
                        cachedBlocks.add(pos);
                    }
                }
            }
        }
    }
}
