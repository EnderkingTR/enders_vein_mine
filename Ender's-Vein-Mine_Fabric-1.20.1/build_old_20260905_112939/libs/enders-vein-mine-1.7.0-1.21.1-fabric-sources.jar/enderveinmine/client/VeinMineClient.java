package enderveinmine.client;

import enderveinmine.config.VeinMineConfig;
import enderveinmine.network.VeinMineActivePayload;
import enderveinmine.network.VeinMineConfigPayload;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

public class VeinMineClient implements ClientModInitializer {
    
    private static class_304 activateKey;
    private static class_304 settingsKey;
    private static class_304 nextShapeKey;
    private static class_304 prevShapeKey;
    
    private static boolean lastActiveState = false;

    @Override
    public void onInitializeClient() {
        String category = "category.vein-mine";

        activateKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.vein-mine.activate",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_GRAVE_ACCENT,
                category
        ));

        settingsKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.vein-mine.settings",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_K,
                category
        ));

        nextShapeKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.vein-mine.next_shape",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_RIGHT_BRACKET,
                category
        ));

        prevShapeKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.vein-mine.prev_shape",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_LEFT_BRACKET,
                category
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.field_1724 == null) return;
            
            while (settingsKey.method_1436()) {
                client.method_1507(VeinMineConfigScreen.create(null));
            }

            boolean shapeChanged = false;
            while (nextShapeKey.method_1436()) {
                VeinMineConfig.ShapeMode[] modes = VeinMineConfig.ShapeMode.values();
                int nextOrd = (VeinMineConfig.INSTANCE.shapeMode.ordinal() + 1) % modes.length;
                VeinMineConfig.INSTANCE.shapeMode = modes[nextOrd];
                shapeChanged = true;
            }
            while (prevShapeKey.method_1436()) {
                VeinMineConfig.ShapeMode[] modes = VeinMineConfig.ShapeMode.values();
                int prevOrd = (VeinMineConfig.INSTANCE.shapeMode.ordinal() - 1 + modes.length) % modes.length;
                VeinMineConfig.INSTANCE.shapeMode = modes[prevOrd];
                shapeChanged = true;
            }

            if (shapeChanged) {
                VeinMineConfig.save();
                sendConfigToServer();
                String modeName = VeinMineConfig.INSTANCE.shapeMode.name();
                net.minecraft.class_5250 msg = net.minecraft.class_2561.method_43469("message.veinmine.mode_changed", 
                        net.minecraft.class_2561.method_43471("config.veinmine.enum.shape." + modeName.toLowerCase(java.util.Locale.ROOT)));
                if (modeName.startsWith("TUNNEL") || modeName.startsWith("STAIRS")) {
                    msg.method_10852(net.minecraft.class_2561.method_43470(" - "))
                       .method_10852(net.minecraft.class_2561.method_43469("message.veinmine.max_blocks", VeinMineConfig.INSTANCE.maxBlocks));
                }
                client.field_1724.method_7353(msg, false);
            }

            boolean isActive = lastActiveState;
            boolean stateChanged = false;

            if (VeinMineConfig.INSTANCE.activationMode == VeinMineConfig.ActivationMode.SNEAK) {
                isActive = client.field_1724.method_18276();
            } else if (VeinMineConfig.INSTANCE.activationMode == VeinMineConfig.ActivationMode.HOLD_KEY) {
                isActive = activateKey.method_1434();
            } else if (VeinMineConfig.INSTANCE.activationMode == VeinMineConfig.ActivationMode.TOGGLE) {
                while (activateKey.method_1436()) {
                    isActive = !isActive;
                }
            }

            if (isActive != lastActiveState) {
                lastActiveState = isActive;
                sendActiveState(isActive);
            }
        });

        net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents.LAST.register(new BlockOutlineRenderer());
    }
    
    public static boolean isActive() {
        return lastActiveState;
    }
    
    public static void sendActiveState(boolean active) {
        if (ClientPlayNetworking.canSend(VeinMineActivePayload.ID)) {
            ClientPlayNetworking.send(new VeinMineActivePayload(active));
        }
    }

    public static void sendConfigToServer() {
        if (ClientPlayNetworking.canSend(VeinMineConfigPayload.ID)) {
            ClientPlayNetworking.send(new VeinMineConfigPayload(VeinMineConfig.INSTANCE));
        }
    }
}