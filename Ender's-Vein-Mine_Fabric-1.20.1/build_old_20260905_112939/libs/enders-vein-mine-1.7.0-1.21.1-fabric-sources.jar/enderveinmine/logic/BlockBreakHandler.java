package enderveinmine.logic;

import enderveinmine.PlayerState;
import enderveinmine.config.VeinMineConfig;
import enderveinmine.network.VeinMineConfigPayload;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.minecraft.class_1799;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Set;

public class BlockBreakHandler {
    
    // Prevent recursive calls during our own block breaking
    private static final ThreadLocal<Boolean> IS_VEIN_MINING = ThreadLocal.withInitial(() -> false);

    public static void register() {
        PlayerBlockBreakEvents.BEFORE.register((level, player, pos, state, blockEntity) -> {
            if (level.method_8608() || !(player instanceof class_3222 serverPlayer)) return true;
            if (IS_VEIN_MINING.get()) return true;

            PlayerState pState = PlayerState.getState(player.method_5667());
            if (!pState.active) return true;
            
            // Fallback to server config if player hasn't sent theirs (or for safety)
            VeinMineConfigPayload config = pState.config;
            int maxBlocks = config != null ? config.maxBlocks() : VeinMineConfig.INSTANCE.maxBlocks;
            boolean damageTool = config != null ? config.damageTool() : VeinMineConfig.INSTANCE.damageTool;
            String shapeModeStr = config != null ? config.shapeMode() : VeinMineConfig.INSTANCE.shapeMode.name();
            String customShape = config != null ? config.customShape() : VeinMineConfig.INSTANCE.customShape;
            boolean directDrop = config != null ? config.directDropToInventory() : VeinMineConfig.INSTANCE.directDropToInventory;
            boolean preventToolBreak = config != null ? config.preventToolBreak() : VeinMineConfig.INSTANCE.preventToolBreak;
            boolean hungerDrain = config != null ? config.hungerDrain() : VeinMineConfig.INSTANCE.hungerDrain;

            if (hungerDrain && serverPlayer.method_7344().method_7586() <= 0) {
                return true; // Allow breaking the single block, but don't vein mine
            }

            IS_VEIN_MINING.set(true);
            try {
                class_1799 tool = serverPlayer.method_6047();
                if (preventToolBreak && damageTool && tool.method_7963() && (tool.method_7936() - tool.method_7919() <= 1)) {
                    return true;
                }

                if (breakBlock((class_3218) level, serverPlayer, pos, state, tool, damageTool, directDrop)) {
                    serverPlayer.method_7259(net.minecraft.class_3468.field_15427.method_14956(state.method_26204()));
                    serverPlayer.method_7322(0.005F);
                    if (hungerDrain) {
                        serverPlayer.method_7322(0.05F);
                    }
                    
                    if ("SHAPED".equals(shapeModeStr)) {
                        handleShapedMine((class_3218) level, serverPlayer, pos, state, customShape, maxBlocks, damageTool, directDrop, preventToolBreak, hungerDrain);
                    } else if ("SHAPELESS".equals(shapeModeStr)) {
                        handleShapelessMine((class_3218) level, serverPlayer, pos, state, maxBlocks, damageTool, directDrop, preventToolBreak, hungerDrain);
                    } else {
                        handlePresetMine((class_3218) level, serverPlayer, pos, state, shapeModeStr, maxBlocks, damageTool, directDrop, preventToolBreak, hungerDrain);
                    }
                    return false;
                }
            } finally {
                IS_VEIN_MINING.set(false);
            }
            return true;
        });
    }

    private static void handleShapelessMine(class_3218 level, class_3222 player, class_2338 startPos, class_2680 startState, int maxBlocks, boolean damageTool, boolean directDrop, boolean preventToolBreak, boolean hungerDrain) {
        class_2248 targetBlock = startState.method_26204();
        Queue<class_2338> queue = new LinkedList<>();
        Set<class_2338> visited = new HashSet<>();
        
        queue.add(startPos);
        visited.add(startPos);
        
        int brokenCount = 1; // 1 for the already broken block
        
        class_1799 tool = player.method_6047();
        boolean checkTool = !tool.method_7960();

        while (!queue.isEmpty() && brokenCount < maxBlocks) {
            class_2338 current = queue.poll();
            
            for (int x = -1; x <= 1; x++) {
                for (int y = -1; y <= 1; y++) {
                    for (int z = -1; z <= 1; z++) {
                        if (x == 0 && y == 0 && z == 0) continue;
                        if (brokenCount >= maxBlocks) break;
                        
                        class_2338 offset = current.method_10069(x, y, z);
                        if (!visited.add(offset)) continue;
                        
                        class_2680 state = level.method_8320(offset);
                        if (BlockUtils.isSameBlockGroup(startState, state)) {
                            if (preventToolBreak && damageTool && tool.method_7963() && (tool.method_7936() - tool.method_7919() <= 1)) {
                                return;
                            }
                            if (hungerDrain && player.method_7344().method_7586() <= 0) {
                                return;
                            }
                            if (breakBlock(level, player, offset, state, tool, damageTool, directDrop)) {
                                if (hungerDrain) {
                                    player.method_7322(0.05F);
                                }
                                brokenCount++;
                                queue.add(offset);
                                if (checkTool && tool.method_7960()) break; // Tool broke
                            }
                        }
                    }
                    if (brokenCount >= maxBlocks || (checkTool && tool.method_7960())) break;
                }
                if (brokenCount >= maxBlocks || (checkTool && tool.method_7960())) break;
            }
        }
    }

    private static void handleShapedMine(class_3218 level, class_3222 player, class_2338 startPos, class_2680 startState, String customShape, int maxBlocks, boolean damageTool, boolean directDrop, boolean preventToolBreak, boolean hungerDrain) {
        float maxHardness = startState.method_26214(level, startPos);
        if (maxHardness < 0) return; // Unbreakable

        int dx = 3, dy = 3, dz = 3;
        try {
            String[] parts = customShape.toLowerCase().split("x");
            if (parts.length == 3) {
                dx = Integer.parseInt(parts[0].trim());
                dy = Integer.parseInt(parts[1].trim());
                dz = Integer.parseInt(parts[2].trim());
            }
        } catch (Exception ignored) {
        }
        
        int hx = dx / 2;
        int hy = dy / 2;
        int hz = dz / 2;
        
        int brokenCount = 1;
        class_1799 tool = player.method_6047();
        boolean checkTool = !tool.method_7960();

        // Simple iteration in the box
        for (int x = -hx; x <= hx; x++) {
            for (int y = -hy; y <= hy; y++) {
                for (int z = -hz; z <= hz; z++) {
                    if (x == 0 && y == 0 && z == 0) continue; // The starting block
                    if (brokenCount >= maxBlocks) return;
                    
                    class_2338 pos = startPos.method_10069(x, y, z);
                    class_2680 state = level.method_8320(pos);
                    float hardness = state.method_26214(level, pos);
                    
                    // Break if hardness is less than or equal to the starting block, and it's not air/unbreakable
                    if (hardness >= 0 && hardness <= maxHardness && !state.method_26215()) {
                        if (preventToolBreak && damageTool && tool.method_7963() && (tool.method_7936() - tool.method_7919() <= 1)) {
                            return;
                        }
                        if (hungerDrain && player.method_7344().method_7586() <= 0) {
                            return;
                        }
                        if (breakBlock(level, player, pos, state, tool, damageTool, directDrop)) {
                            if (hungerDrain) {
                                player.method_7322(0.05F);
                            }
                            brokenCount++;
                            if (checkTool && tool.method_7960()) return;
                        }
                    }
                }
            }
        }
    }



    private static void handlePresetMine(class_3218 level, class_3222 player, class_2338 startPos, class_2680 startState, String mode, int maxBlocks, boolean damageTool, boolean directDrop, boolean preventToolBreak, boolean hungerDrain) {
        class_2248 targetBlock = startState.method_26204();
        net.minecraft.class_2350 viewDir = net.minecraft.class_2350.method_10159(player)[0];
        
        int brokenCount = 1;
        class_1799 tool = player.method_6047();
        boolean checkTool = !tool.method_7960();

        net.minecraft.class_2350 upDir = net.minecraft.class_2350.field_11036;
        net.minecraft.class_2350 rightDir; 
        if (viewDir == net.minecraft.class_2350.field_11036 || viewDir == net.minecraft.class_2350.field_11033) {
            net.minecraft.class_2350 playerFacing = player.method_5735();
            if (playerFacing.method_10166() == net.minecraft.class_2350.class_2351.field_11052) {
                playerFacing = net.minecraft.class_2350.field_11043;
            }
            upDir = playerFacing.method_10153(); // backward relative to player's horizontal looking
            rightDir = playerFacing.method_10170();
        } else {
            rightDir = viewDir.method_10170();
        }

        for (int depth = 0; depth < maxBlocks; depth++) {
            if (brokenCount >= maxBlocks) break;

            int minR = 0, maxR = 0;
            int minU = 0, maxU = 0;
            int fOffset = depth;
            int uOffset = 0;
            
            switch (mode) {
                case "TUNNEL_3X3":
                    minR = -1; maxR = 1;
                    minU = -1; maxU = 1;
                    break;
                case "TUNNEL_2X1":
                    minR = 0; maxR = 0; // width 1
                    minU = 0; maxU = 1; // height 2
                    break;
                case "STAIRS_UP":
                    minR = 0; maxR = 0; // width 1
                    minU = 0; maxU = 2; // 3 blocks high
                    uOffset = depth; // go up 1 per depth
                    break;
                case "STAIRS_DOWN":
                    minR = 0; maxR = 0; // width 1
                    minU = 0; maxU = 2; // 3 blocks high
                    uOffset = -depth; // go down 1 per depth
                    break;
                case "TUNNEL_1X1":
                    minR = 0; maxR = 0;
                    minU = 0; maxU = 0;
                    break;
            }

            for (int r = minR; r <= maxR; r++) {
                for (int u = minU; u <= maxU; u++) {
                    if (depth == 0 && r == 0 && u == 0 && uOffset == 0) continue;

                    if (brokenCount >= maxBlocks) return;

                    class_2338 pos = startPos
                        .method_10079(viewDir, fOffset)
                        .method_10079(rightDir, r)
                        .method_10079(upDir, u + uOffset);
                    
                    class_2680 state = level.method_8320(pos);
                    
                    if (BlockUtils.isSameBlockGroup(startState, state)) {
                        if (preventToolBreak && damageTool && tool.method_7963() && (tool.method_7936() - tool.method_7919() <= 1)) {
                            return;
                        }
                        if (hungerDrain && player.method_7344().method_7586() <= 0) {
                            return;
                        }
                        if (breakBlock(level, player, pos, state, tool, damageTool, directDrop)) {
                            if (hungerDrain) {
                                player.method_7322(0.05F);
                            }
                            brokenCount++;
                            if (checkTool && tool.method_7960()) return;
                        }
                    }
                }
            }
        }
    }

    private static boolean breakBlock(class_3218 level, class_3222 player, class_2338 pos, class_2680 state, class_1799 tool, boolean damageTool, boolean directDrop) {
        class_2586 blockEntity = level.method_8321(pos);
        
        java.util.List<class_1799> drops = class_2248.method_9609(state, level, pos, blockEntity, player, tool);
        
        class_2248 block = state.method_26204();
        if (block instanceof net.minecraft.class_2542) {
            for (net.minecraft.class_2769<?> prop : state.method_28501()) {
                if (prop.method_11899().equals("eggs") && prop instanceof net.minecraft.class_2758 intProp) {
                    int count = state.method_11654(intProp);
                    for (class_1799 drop : drops) {
                        if (drop.method_31574(net.minecraft.class_1802.field_8618)) {
                            drop.method_7939(count);
                        }
                    }
                }
            }
        } else if (block instanceof net.minecraft.class_2472) {
            for (net.minecraft.class_2769<?> prop : state.method_28501()) {
                if (prop.method_11899().equals("pickles") && prop instanceof net.minecraft.class_2758 intProp) {
                    int count = state.method_11654(intProp);
                    for (class_1799 drop : drops) {
                        if (drop.method_31574(net.minecraft.class_1802.field_17498)) {
                            drop.method_7939(count);
                        }
                    }
                }
            }
        }
        
        boolean success = level.method_8651(pos, false, player);
        if (success) {
            if (directDrop) {
                for (class_1799 drop : drops) {
                    player.method_31548().method_7394(drop);
                    if (!drop.method_7960()) {
                        player.method_7328(drop, false);
                    }
                }
            } else {
                for (class_1799 drop : drops) {
                    class_2248.method_9577(level, pos, drop);
                }
            }
            
            ((enderveinmine.mixin.BlockBehaviourAccessor) state.method_26204()).invokeSpawnAfterBreak(state, level, pos, tool, true);
            
            if (directDrop) {
                net.minecraft.class_238 box = new net.minecraft.class_238(pos).method_1014(1.0);
                java.util.List<net.minecraft.class_1303> orbs = level.method_18467(net.minecraft.class_1303.class, box);
                for (net.minecraft.class_1303 orb : orbs) {
                    if (orb.field_6012 <= 1) {
                        orb.method_5814(player.method_23317(), player.method_23318(), player.method_23321());
                    }
                }
            }
            
            if (damageTool && tool.method_7963()) {
                tool.method_7970(1, player, net.minecraft.class_1304.field_6173);
            }
        }
        return success;
    }
}
