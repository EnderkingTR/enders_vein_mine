package enderveinmine.logic;

import enderveinmine.PlayerState;
import enderveinmine.config.VeinMineConfig;
import enderveinmine.network.VeinMineConfigPayload;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1799;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.class_3965;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Set;

public class BlockInteractHandler {

    private static final ThreadLocal<Boolean> IS_VEIN_INTERACTING = ThreadLocal.withInitial(() -> false);

    private static boolean isHarvestableCrop(class_2680 state, class_1937 level, class_2338 pos) {
        class_2248 block = state.method_26204();
        if (block instanceof net.minecraft.class_2302 crop) {
            return crop.method_9825(state);
        }
        if (block instanceof net.minecraft.class_2421) {
            return state.method_11654(net.minecraft.class_2421.field_11306) >= 3;
        }
        if (block instanceof net.minecraft.class_2282) {
            return state.method_11654(net.minecraft.class_2282.field_10779) >= 2;
        }
        if (block instanceof net.minecraft.class_2523
                || block instanceof net.minecraft.class_2266) {
            class_2680 stateBelow = level.method_8320(pos.method_10074());
            return stateBelow.method_26204() == block;
        }
        return false;
    }

    private static boolean harvestCrop(class_3222 player, class_1937 level, class_2338 pos, class_2680 state,
            class_1799 tool) {
        if (!(level instanceof net.minecraft.class_3218 serverLevel))
            return false;
        class_2248 block = state.method_26204();

        PlayerState pState = PlayerState.getState(player.method_5667());
        boolean directDrop = false;
        if (pState != null && pState.config != null) {
            directDrop = pState.config.directDropToInventory();
        } else {
            directDrop = VeinMineConfig.INSTANCE.directDropToInventory;
        }

        if (block instanceof net.minecraft.class_2302 crop) {
            java.util.List<class_1799> drops = class_2248.method_9609(state, serverLevel, pos, null, player, tool);
            boolean seedRemoved = false;
            for (class_1799 drop : drops) {
                if (!seedRemoved && drop.method_7909() instanceof net.minecraft.class_1747 blockItem
                        && blockItem.method_7711() == crop) {
                    drop.method_7934(1);
                    seedRemoved = true;
                }
                if (!drop.method_7960()) {
                    if (directDrop) {
                        player.method_31548().method_7394(drop);
                        if (!drop.method_7960()) {
                            player.method_7328(drop, false);
                        }
                    } else {
                        class_2248.method_9577(level, pos, drop);
                    }
                }
            }
            level.method_8501(pos, crop.method_9828(0));
            return true;
        }

        if (block instanceof net.minecraft.class_2421) {
            java.util.List<class_1799> drops = class_2248.method_9609(state, serverLevel, pos, null, player, tool);
            boolean seedRemoved = false;
            for (class_1799 drop : drops) {
                if (!seedRemoved && drop.method_31574(net.minecraft.class_1802.field_8790)) {
                    drop.method_7934(1);
                    seedRemoved = true;
                }
                if (!drop.method_7960()) {
                    if (directDrop) {
                        player.method_31548().method_7394(drop);
                        if (!drop.method_7960()) {
                            player.method_7328(drop, false);
                        }
                    } else {
                        class_2248.method_9577(level, pos, drop);
                    }
                }
            }
            level.method_8501(pos, state.method_11657(net.minecraft.class_2421.field_11306, 0));
            return true;
        }

        if (block instanceof net.minecraft.class_2282) {
            java.util.List<class_1799> drops = class_2248.method_9609(state, serverLevel, pos, null, player, tool);
            boolean seedRemoved = false;
            for (class_1799 drop : drops) {
                if (!seedRemoved && drop.method_31574(net.minecraft.class_1802.field_8116)) {
                    drop.method_7934(1);
                    seedRemoved = true;
                }
                if (!drop.method_7960()) {
                    if (directDrop) {
                        player.method_31548().method_7394(drop);
                        if (!drop.method_7960()) {
                            player.method_7328(drop, false);
                        }
                    } else {
                        class_2248.method_9577(level, pos, drop);
                    }
                }
            }
            level.method_8501(pos, state.method_11657(net.minecraft.class_2282.field_10779, 0));
            return true;
        }

        if (block instanceof net.minecraft.class_2523
                || block instanceof net.minecraft.class_2266) {
            java.util.List<class_1799> drops = class_2248.method_9609(state, serverLevel, pos, null, player, tool);
            for (class_1799 drop : drops) {
                if (directDrop) {
                    player.method_31548().method_7394(drop);
                    if (!drop.method_7960()) {
                        player.method_7328(drop, false);
                    }
                } else {
                    class_2248.method_9577(level, pos, drop);
                }
            }
            level.method_8501(pos, net.minecraft.class_2246.field_10124.method_9564());
            return true;
        }

        return false;
    }

    public static void register() {
        UseBlockCallback.EVENT.register((player, level, hand, hitResult) -> {
            if (level.method_8608() || !(player instanceof class_3222 serverPlayer))
                return class_1269.field_5811;
            if (IS_VEIN_INTERACTING.get())
                return class_1269.field_5811;

            PlayerState pState = PlayerState.getState(player.method_5667());
            if (!pState.active)
                return class_1269.field_5811;

            class_1799 tool = player.method_5998(hand);

            class_2338 startPos = hitResult.method_17777();
            class_2680 startState = level.method_8320(startPos);

            IS_VEIN_INTERACTING.set(true);
            try {
                boolean isCrop = isHarvestableCrop(startState, level, startPos);
                class_1269 initialResult = class_1269.field_5811;
                boolean consumed = false;

                if (isCrop) {
                    if (harvestCrop(serverPlayer, level, startPos, startState, tool)) {
                        consumed = true;
                        initialResult = class_1269.field_5812;
                    }
                } else {
                    if (tool.method_7960())
                        return class_1269.field_5811;
                    class_1838 context = new class_1838(player, hand, hitResult);
                    initialResult = tool.method_7981(context);
                    consumed = initialResult.method_23665();
                }

                if (consumed) {
                    VeinMineConfigPayload config = pState.config;
                    int maxBlocks = config != null ? config.maxBlocks() : VeinMineConfig.INSTANCE.maxBlocks;
                    String shapeModeStr = config != null ? config.shapeMode()
                            : VeinMineConfig.INSTANCE.shapeMode.name();
                    String customShape = config != null ? config.customShape() : VeinMineConfig.INSTANCE.customShape;

                    if ("SHAPED".equals(shapeModeStr)) {
                        handleShapedInteract(serverPlayer, level, hand, hitResult, startState, customShape, maxBlocks);
                    } else if ("SHAPELESS".equals(shapeModeStr)) {
                        handleShapelessInteract(serverPlayer, level, hand, hitResult, startState, maxBlocks);
                    } else {
                        handlePresetInteract(serverPlayer, level, hand, hitResult, startState, shapeModeStr,
                                maxBlocks);
                    }

                    return initialResult;
                }
            } finally {
                IS_VEIN_INTERACTING.set(false);
            }

            return class_1269.field_5811;
        });
    }

    private static boolean interactBlock(class_3222 player, class_1937 level, class_1268 hand,
            class_3965 hitResult, class_2338 offset, class_2680 targetState) {
        class_2680 state = level.method_8320(offset);
        if (BlockUtils.isSameBlockGroup(targetState, state)) {
            if (isHarvestableCrop(state, level, offset)) {
                return harvestCrop(player, level, offset, state, player.method_5998(hand));
            }

            class_1799 tool = player.method_5998(hand);
            if (tool.method_7960())
                return false;

            class_3965 offsetHit = new class_3965(
                    hitResult.method_17784().method_1031(offset.method_10263() - hitResult.method_17777().method_10263(),
                            offset.method_10264() - hitResult.method_17777().method_10264(),
                            offset.method_10260() - hitResult.method_17777().method_10260()),
                    hitResult.method_17780(),
                    offset,
                    hitResult.method_17781());
            class_1838 offsetContext = new class_1838(player, hand, offsetHit);
            class_1269 result = tool.method_7981(offsetContext);
            return result.method_23665();
        }
        return false;
    }

    private static void handleShapelessInteract(class_3222 player, class_1937 level, class_1268 hand,
            class_3965 hitResult, class_2680 targetState, int maxBlocks) {
        class_2338 startPos = hitResult.method_17777();
        Queue<class_2338> queue = new LinkedList<>();
        Set<class_2338> visited = new HashSet<>();

        queue.add(startPos);
        visited.add(startPos);

        int interactedCount = 1;
        class_1799 tool = player.method_5998(hand);
        boolean checkTool = !tool.method_7960();

        while (!queue.isEmpty() && interactedCount < maxBlocks) {
            class_2338 current = queue.poll();

            for (int x = -1; x <= 1; x++) {
                for (int y = -1; y <= 1; y++) {
                    for (int z = -1; z <= 1; z++) {
                        if (x == 0 && y == 0 && z == 0)
                            continue;
                        if (interactedCount >= maxBlocks)
                            return;

                        class_2338 offset = current.method_10069(x, y, z);
                        if (!visited.add(offset))
                            continue;

                        if (interactBlock(player, level, hand, hitResult, offset, targetState)) {
                            interactedCount++;
                            queue.add(offset);
                            if (checkTool && tool.method_7960())
                                return;
                        }
                    }
                }
            }
        }
    }

    private static void handleShapedInteract(class_3222 player, class_1937 level, class_1268 hand,
            class_3965 hitResult, class_2680 targetState, String customShape, int maxBlocks) {
        class_2338 startPos = hitResult.method_17777();
        int dx = 3, dy = 3, dz = 3;
        try {
            String[] parts = customShape.toLowerCase().split("x");
            if (parts.length == 3) {
                dx = Integer.parseInt(parts[0].trim());
                dy = Integer.parseInt(parts[1].trim());
                dz = Integer.parseInt(parts[2].trim());
            }
        } catch (Exception ignored) {
        }

        int hx = dx / 2;
        int hy = dy / 2;
        int hz = dz / 2;

        int interactedCount = 1;
        class_1799 tool = player.method_5998(hand);
        boolean checkTool = !tool.method_7960();

        for (int x = -hx; x <= hx; x++) {
            for (int y = -hy; y <= hy; y++) {
                for (int z = -hz; z <= hz; z++) {
                    if (x == 0 && y == 0 && z == 0)
                        continue;
                    if (interactedCount >= maxBlocks)
                        return;

                    class_2338 offset = startPos.method_10069(x, y, z);

                    if (interactBlock(player, level, hand, hitResult, offset, targetState)) {
                        interactedCount++;
                        if (checkTool && tool.method_7960())
                            return;
                    }
                }
            }
        }
    }

    private static void handlePresetInteract(class_3222 player, class_1937 level, class_1268 hand,
            class_3965 hitResult, class_2680 targetState, String mode, int maxBlocks) {
        class_2338 startPos = hitResult.method_17777();
        net.minecraft.class_2350 viewDir = net.minecraft.class_2350.method_10159(player)[0];

        int interactedCount = 1;
        class_1799 tool = player.method_5998(hand);
        boolean checkTool = !tool.method_7960();

        net.minecraft.class_2350 upDir = net.minecraft.class_2350.field_11036;
        net.minecraft.class_2350 rightDir;
        if (viewDir == net.minecraft.class_2350.field_11036 || viewDir == net.minecraft.class_2350.field_11033) {
            net.minecraft.class_2350 playerFacing = player.method_5735();
            if (playerFacing.method_10166() == net.minecraft.class_2350.class_2351.field_11052) {
                playerFacing = net.minecraft.class_2350.field_11043;
            }
            upDir = playerFacing.method_10153();
            rightDir = playerFacing.method_10170();
        } else {
            rightDir = viewDir.method_10170();
        }

        for (int depth = 0; depth < maxBlocks; depth++) {
            if (interactedCount >= maxBlocks)
                break;

            int minR = 0, maxR = 0;
            int minU = 0, maxU = 0;
            int fOffset = depth;
            int uOffset = 0;

            switch (mode) {
                case "TUNNEL_3X3":
                    minR = -1;
                    maxR = 1;
                    minU = -1;
                    maxU = 1;
                    break;
                case "TUNNEL_2X1":
                    minR = 0;
                    maxR = 0;
                    minU = 0;
                    maxU = 1;
                    break;
                case "STAIRS_UP":
                    minR = 0;
                    maxR = 0;
                    minU = 0;
                    maxU = 2;
                    uOffset = depth;
                    break;
                case "STAIRS_DOWN":
                    minR = 0;
                    maxR = 0;
                    minU = 0;
                    maxU = 2;
                    uOffset = -depth;
                    break;
                case "TUNNEL_1X1":
                    minR = 0;
                    maxR = 0;
                    minU = 0;
                    maxU = 0;
                    break;
            }

            for (int r = minR; r <= maxR; r++) {
                for (int u = minU; u <= maxU; u++) {
                    if (depth == 0 && r == 0 && u == 0 && uOffset == 0)
                        continue;
                    if (interactedCount >= maxBlocks)
                        return;

                    class_2338 offset = startPos
                            .method_10079(viewDir, fOffset)
                            .method_10079(rightDir, r)
                            .method_10079(upDir, u + uOffset);

                    if (interactBlock(player, level, hand, hitResult, offset, targetState)) {
                        interactedCount++;
                        if (checkTool && tool.method_7960())
                            return;
                    }
                }
            }
        }
    }
}
