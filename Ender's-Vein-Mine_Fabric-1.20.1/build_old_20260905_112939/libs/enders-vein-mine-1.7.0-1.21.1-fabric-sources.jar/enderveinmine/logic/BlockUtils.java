package enderveinmine.logic;

import java.util.Set;
import java.util.stream.Collectors;
import net.minecraft.class_2248;
import net.minecraft.class_2680;
import net.minecraft.class_6862;

public class BlockUtils {

    // A list of tag paths that we consider valid for grouping blocks together
    private static final Set<String> VALID_GROUPING_TAGS = Set.of(
        "ores", "logs", "leaves", "dirts", "sand", "stones", "cobblestones", 
        "glass_blocks", "glass_panes", "base_stone_overworld", "base_stone_nether",
        "dirt", "logs_that_burn", "planks", "wooden_fences", "wooden_doors",
        "wooden_trapdoors", "wooden_stairs", "wooden_slabs", "terracotta"
    );

    public static boolean isSameBlockGroup(class_2680 targetState, class_2680 currentState) {
        if (targetState.method_26204() == currentState.method_26204()) return true;

        Set<class_6862<class_2248>> targetTags = targetState.method_40144().collect(Collectors.toSet());
        Set<class_6862<class_2248>> currentTags = currentState.method_40144().collect(Collectors.toSet());

        for (class_6862<class_2248> tag : targetTags) {
            if (currentTags.contains(tag)) {
                String namespace = tag.comp_327().method_12836();
                String path = tag.comp_327().method_12832();
                
                // Allow grouping if they share a relevant 'c' (conventional) or 'minecraft' tag
                if (namespace.equals("c") || namespace.equals("minecraft")) {
                    // Check if it's one of the common grouping tags
                    // Also check for sub-tags like c:ores/copper -> we can check if it contains "ores" or similar, 
                    // but it's safer to just split by '/' and check the first part.
                    String mainPath = path.split("/")[0];
                    if (VALID_GROUPING_TAGS.contains(mainPath) || VALID_GROUPING_TAGS.contains(path)) {
                        return true;
                    }
                }
            }
        }

        return false;
    }
}
